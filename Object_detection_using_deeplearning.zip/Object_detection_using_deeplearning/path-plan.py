import pygame
import json
import math


"""
Pixels to Centimeters conversion
#pixel data   #actual house front
70px    =     360cm                  -->  360/70 = MAP_SIZE_COEFF
"""
MAP_SIZE_COEFF = 5.14 #this is very important for our path planning because the calculated value here will be multiplied with the dist_cm in get_dist_btw_pos function for real world mapping...

pygame.init()
screen = pygame.display.set_mode([720, 720])
#screen = pygame.display.set_mode([1793, 890])
screen.fill((255,255,255))
running = True


class Background(pygame.sprite.Sprite):
    def __init__(self, image, location, scale):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(image)
        self.image = pygame.transform.rotozoom(self.image, 0, scale)
        self.rect = self.image.get_rect()
        self.rect.left, self.rect.top = location

#this function stores the distance of the line when we click between 2 points and the line is drawn
def get_dist_btw_pos(pos0, pos1):
    """
    GET DISTANCE BETWEEN 2 MOUSE POSITIONS:
    """
    x = abs(pos0[0] - pos1[0])
    y = abs(pos0[1] - pos1[1])
    dist_px = math.hypot(x, y)
    dist_cm = dist_px * MAP_SIZE_COEFF
    return int(dist_cm), int(dist_px)

#path vairables of clicks are stored here..
path_wp = []
index = 0



"""
Angle Computation between two lines respective to posRef..
"""
def get_angle_btw_line(pos0, pos1, posref):
    #using dot product calculation
    ax = posref[0] - pos0[0]
    ay = posref[1] - pos0[1]
    bx = posref[0] - pos1[0]
    by = posref[1] - pos1[1]
#get the dot product of pos0 and pos1
    _dot = (ax * bx) + (ay * by)
    #get magnitude of pos0 and pos1
    _magA = math.sqrt(pow(ax,2) + pow(ay,2))
    _magB = math.sqrt(pow(bx, 2) + pow(by, 2))
    _rad = math.cos(_dot / (_magA * _magB))
    #Angles in degrees.
    angle = (_rad * 180) / math.pi
    return int(angle)



"""
Main Capturing Mouse Program...
"""
#LOAD BACKGROUND IMAGE...
bground = Background('image.png', [0,0], 1.0)
screen.blit(bground.image, bground.rect)


#making of the 720x720 window
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:  #this is done for everytime a click is pressed the position of the mouse is stored in the pos variable
            pos = pygame.mouse.get_pos()
            path_wp.append(pos)
            if index > 0:                                                    #width of line drawn
                pygame.draw.line(screen, (255, 0, 0), path_wp[index-1], pos, 2)
            index += 1
    pygame.display.update()


"""
Computing the waypoints (distance and angle).
"""
#appending the reference start for angle of initial point..
path_wp.insert(0, (path_wp[0][0], path_wp[0][1] - 10))
path_dist_cm = []
path_dist_px = []
path_angle = []
for index in range(len(path_wp)):
    #Skip the first and secondindex...
    if index > 1:
        dist_cm, dist_px = get_dist_btw_pos(path_wp[index-1], path_wp[index])
        path_dist_cm.append(dist_cm)
        path_dist_px.append(dist_px)

    #skip the first and last index
    if index > 0 and index < (len(path_wp) - 1): #this is for a single line where we wont be able to capture the angle...
        angle = get_angle_btw_line(path_wp[index-1], path_wp[index+1], path_wp[index])
        path_angle.append(angle)


#Printing the information...
print(f"path_wp {path_wp}")
print(f"dist_cm: {path_dist_cm}")
print(f"dist_px: {path_dist_px}")
print(f"dis_angle: {path_angle}")


"""
Save waypoints into JSON file
"""

waypoints = []
for index in range(len(path_dist_cm)):
    waypoints.append({
        "dist_cm": path_dist_cm[index],
        "dist_px": path_dist_px[index],
        "angle_deg": path_angle[index]
    })

#save to JSON file.
f = open("waypoint.json", "w+")
path_wp.pop(0)
json.dump({
    "wp": waypoints,
    "pos": path_wp
},f, indent=4)
f.close()

















































































































































